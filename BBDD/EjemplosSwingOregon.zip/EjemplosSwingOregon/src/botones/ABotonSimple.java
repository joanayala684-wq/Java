package botones;

import javax.swing.*;    

public class ABotonSimple {  
    public static void main(String[] args) {  
        JFrame frame = new JFrame("Ejemplo de JButton");  
        JButton boton = new JButton("Haz clic aqu�");  
        boton.setBounds(50, 100, 120, 30);  // Posici�n y tama�o del bot�n

        frame.add(boton);  // Agregar bot�n al JFrame
        frame.setSize(400, 400);  // Tama�o del JFrame
        frame.setLayout(null);  // Sin gestor de dise�o
        frame.setVisible(true);  // Hacer visible el JFrame
    }  
}