package basicos;

import javax.swing.*;  

public class AEjemploSwingEnMain {  
    public static void main(String[] args) {  
        JFrame frame = new JFrame(); // Creando instancia de JFrame
        JButton boton = new JButton("Haz clic"); // Creando un bot�n

        // Estableciendo posici�n y tama�o del bot�n
        boton.setBounds(130, 100, 100, 40);  

        // A�adiendo el bot�n al marco
        frame.add(boton);  

        // Configuraci�n del JFrame
        frame.setSize(400, 500);  
        frame.setLayout(null);  
        frame.setVisible(true);  
    }  
}