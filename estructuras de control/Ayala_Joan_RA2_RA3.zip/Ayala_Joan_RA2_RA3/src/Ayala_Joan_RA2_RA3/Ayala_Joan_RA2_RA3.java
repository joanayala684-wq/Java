package Ayala_Joan_RA2_RA3;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Ayala_Joan_RA2_RA3 {
	static Scanner sc;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Ayala_Joan_RA2_RA3
		sc = new Scanner(System.in);
		boolean cod_correcto = false;
		String cod_emple = null;
		int incidencia=0;
		LocalTime hora1 = null, hora2 = null;
		do {
			System.out.println("introduce el codigo del empleado");
			cod_emple = sc.nextLine();
			try {
				cod_correcto = ValidarCodEmple(cod_emple);
			} catch (NumFueraRangoException e) {
				System.out.println(e.getMessage());
			} catch (NullPointerException e) {
				System.out.println("introduce algun valor para el codigo emple");
			}

		} while (!cod_correcto);
		boolean correcto = false;
		do {
			System.out.println("introduce tu hora de entrada");
			String hora1S = sc.nextLine();
			System.out.println("introduce tu hora de entrada");
			String hora2S = sc.nextLine();
			try {
				hora1 = LocalTime.parse(hora1S);
				correcto = true;
			} catch (DateTimeParseException e) {
				System.out.println("error al introducir la hora, vuelve a intentarlo");
			}
		} while (correcto == false);
		for (int i = 1; i <= 5; i++) {
			do {
				System.out.println("introduce la otra hora");
				String hora2S = sc.nextLine();
				try {
					hora2 = LocalTime.parse(hora2S);
					if (hora2.isBefore(hora1)) {
						System.out.println("la hora de salida debe ser posterior a la de entrada");
					}
					else {
					correcto = true;}
				} catch (DateTimeParseException e) {
					System.out.println("error al introducir la hora, vuelve a intentarlo");

				}

			} while (!correcto);
			LocalTime horas_trabajadas=null;
			try {
				horas_trabajadas=CalcularHoras(hora1, hora2, cod_emple);
			} catch (Ayala_JoanException e) {
				System.out.println(e.getMessage());
			}
			System.out.println("las horas trabajadas hoy son " + horas_trabajadas);
			
		}
		
	}

	public static boolean ValidarCodEmple(String cod_emple) throws NumFueraRangoException {
		String depart , numeros ;
		depart = cod_emple.substring(0, (cod_emple.length() - 4));
		String patron = "^[A-Za-z]{3,4}[0][0-9]{3}$";
		assert (depart.equalsIgnoreCase("mkt") && depart.equalsIgnoreCase("des") &&depart.equalsIgnoreCase("rrh")): "los unicos departamentos validos son: MKT, DES, RHH";
		numeros = cod_emple.substring(4);
		//numeros = cod_emple.substring(depart.lenght(),cod_emple.leght();//
		if (!cod_emple.matches(patron)) {
			return false;
		}
		int numero = Integer.parseInt(numeros);
		if (numero < 100 && numero < 500) {
			throw new NumFueraRangoException("el numero de empleado debe estar comprendido entre 0100 y 0500");
		}

		return true;

	}
	public static LocalTime CalcularHoras (LocalTime hora1, LocalTime hora2, String cod_emple) throws Ayala_JoanException {
		String depart = cod_emple.substring(0, (cod_emple.length() - 4));
		long diferenciaHoras =(int)Math.abs(ChronoUnit.HOURS.between(hora1, hora2));
		long diferenciaMinutos = (int)Math.abs(ChronoUnit.MINUTES.between(hora1, hora2));
		LocalTime jornada=null;
		jornada=LocalTime.of((int)diferenciaHoras,(int) diferenciaMinutos);
		if(depart.equalsIgnoreCase("MKT") ){
			LocalTime entrada=LocalTime.of(10,00);
			LocalTime salida=LocalTime.of(18,00);
			if(hora1.isAfter(entrada) || hora2.isBefore(salida)) {
				throw new Ayala_JoanException("se ha producido una incidencia");
			}
				
		}
		if(depart.equalsIgnoreCase("DES") ){
			LocalTime entrada=LocalTime.of(8,30);
			LocalTime salida=LocalTime.of(16,00);
			if(hora1.isAfter(entrada) || hora2.isBefore(salida)) {
				throw new Ayala_JoanException("se ha producido una incidencia");
			}
				
		}
		if(depart.equalsIgnoreCase("RRHH") ){
			LocalTime entrada=LocalTime.of(9,00);
			LocalTime salida=LocalTime.of(16,30);
			if(hora1.isAfter(entrada) || hora2.isBefore(salida)) {
				throw new Ayala_JoanException("se ha producido una incidencia");
			}
				
		}
		return jornada;
		}

}
