package arrays;

import java.util.Scanner;

public class exam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		double temperaturas[] = new double[7];
		double umbral[]=new double [7];
		double media, valorUmbral;
		int cont;
		rellenartemp(temperaturas, sc);
		
		System.out.println("Array rellenado con exito");
		media=CalcularMed(temperaturas);
		System.out.println("la media de las temperaturas de la semana es de "+media);
		System.out.println("introduce un valor umbral para el filtrado");
		valorUmbral=sc.nextDouble();
		System.out.println("las tempperaturas que superan el umbral son:");
		cont=filtrarValor(umbral, temperaturas,  valorUmbral);
		for (int i = 0; i < cont; i++) {
			System.out.println(umbral[i]);
		}
		
		
	}
	public static void rellenartemp(double[] temperaturas, Scanner sc) {
		for (int i = 0; i < temperaturas.length; i++) {
			double temp = 0;
			do {
				System.out.println("introduce la temperatura del dia dela semana, dia num: " + (i+1));
				temp = sc.nextDouble();
				if (temp < (-20) || temp > 50)
					System.out.println("temperatura fuera de nivel realista, vuelve a intertarlo");

			} while (temp < (-20) || temp > 50);
			temperaturas[i] = temp;
		}
	}
	public static double CalcularMed (double[] temperaturas) {
		double suma=0;
		for (int i = 0; i < temperaturas.length; i++) {
			suma+=temperaturas[i];
		}
		
		return suma/7;
		
	}
	public static int filtrarValor(double[] umbral, double[] temperaturas, double valorUmbral) {
		int cont=0;
		for (int i = 0; i < temperaturas.length; i++) {
			if(temperaturas[i]>valorUmbral) {
				umbral[cont]=temperaturas[i];
				cont++;
			}
			
		}
		return cont;
			
		
	}
	public static double TempMax(double[] temperaturas) {
		
	}
	

}
